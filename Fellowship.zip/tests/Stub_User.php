<?php

namespace App;

use EloquentWorks\Fellowship\Traits\HasFriendships;
use Illuminate\Auth\Authenticatable;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\Access\Authorizable;

class User extends Model implements AuthenticatableContract, AuthorizableContract, CanResetPasswordContract
{
    use Authenticatable;
    use Authorizable;
    use CanResetPassword;
    use HasFriendships;

    /** @var string The database table used by the model. */
    protected $table = 'users';

    /** @var array The attributes that are mass assignable. */
    protected $fillable = ['name', 'email', 'password'];

    /** @var array The attributes excluded from the model's JSON form. */
    protected $hidden = ['password', 'remember_token'];
}
